# -*- coding: utf-8 -*-
import httplib,json,os

proxy=None
host = "www.irem.sciences.univ-nantes.fr"
service = '/dyn/data'

def get_proxy() :
    global proxy
    if proxy : return 
    proxy=os.getenv('http_proxy')
    if not proxy : proxy = os.getenv('HTTP_PROXY')
    if proxy and proxy[:7] == "http://" :
        proxy =  proxy[7:]


def get_dataset(exo) :
    get_proxy()
    request = service + '/random/' + str(exo)
    if proxy :
        h = httplib.HTTPConnection(proxy)
        h.request('GET', 'http://' + host + request)
    else:
        h = httplib.HTTPConnection(host)
        h.request('GET', request)
    resp = h.getresponse()
    h.close()
    if resp.status == 200:
        bd = json.loads(resp.read())
        return bd['id_set'], bd['param']
    if resp.status == 400 or resp.status == 500 :
        bd = json.loads(resp.read())
        print bd['name']
        print bd['message']
    else:
        print httplib.responses[resp.status]
        
def show_example(exo) :
    get_proxy()
    request = service + '/example/' + str(exo)
    if proxy :
        h = httplib.HTTPConnection(proxy)
        h.request('GET', 'http://' + host + request)
    else:
        h = httplib.HTTPConnection(host)
        h.request('GET', request)
    resp = h.getresponse()
    h.close()
    if resp.status == 200:
        bd = json.loads(resp.read())
        print "Parameter :" , bd['param']
        print "Result    :" , bd['result']
    if resp.status == 400 or resp.status == 500 :
        bd = json.loads(resp.read())
        print bd['name']
        print bd['message']
    else:
        print httplib.responses[resp.status]
        
def getuser() :
    etud = os.getenv("LOGNAME")
    if etud[0] == 'E' : etud = etud[1:]
    print "Identifiant :", etud
    return etud

def submit_result(id_set,result,etud=None) :
    get_proxy()
    if not etud : etud = getuser()
    request = service + '/submit/' + etud + '/' +  str(id_set)
    dump = json.dumps(result)
    if proxy :
        h = httplib.HTTPConnection(proxy)
        h.request('PUT', 'http://' + host + request, dump, {"Content-Type" : "application/json"})
    else:
        h = httplib.HTTPConnection(host)
        h.request('PUT', request, dump, {"Content-Type" : "application/json"})
    resp = h.getresponse()
    h.close()
    if resp.status == 200 :
        print "Résultat correct."
    elif resp.status == 202 :
        bd = json.loads(resp.read())
        print bd['name']
        print bd['message']
    else :
        bd = json.loads(resp.read())
        print bd['name']
        print bd['message']
        print "Identifiant de l'étudiant ou id dataset inconnu."
        



if __name__ == "__main__" :
    print """

Ce module définit trois fonctions :

get_dataset(exo)          : Cette fonction prend comme argument
                            un entier qui est un numéro d'exercice.
                            Elle renvoie un couple (id,param) où
                            id est un numéro identifiant le dataset
                            param est l'argument pour la fonction
                            client.

show_example(exo)         : Cette fonction affiche des exemples pour
                            l'exercice spécifié par l'entier exo.

submit_result(id, result) : Cette fonction envoie le resultat de la
                            fonction client.
"""
        

