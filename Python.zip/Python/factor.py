#! /usr/bin/env python
# -*-coding:utf-8 -*
import math
execfile('premiers.py')
	
def factor(liste):
	reponse=[]
	racine=int(math.sqrt(max(liste)))
	a=premiers(racine)
	for n in liste:
		l=[]
		for i in a:
			count=0
			while n%i==0:
				n=n/i
				count=count+1
			if count!=0:
				l.append([i,count])
		if n!=1:
			l.append([n,1])
		reponse.append(l)
	return reponse
