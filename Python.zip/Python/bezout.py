#! /usr/bin/env python
# -*-coding:utf-8 -*
import math
execfile('premiers.py')

def pgcd(a,b) :
    if (b==0) :
        return(a)
    else :
        r=a%b
        return algo_euclide(b,r)
        
def bezout(a,b):
	r1,r2=a,b
	u1,v1,u2,v2=1,0,0,1
	while (r2!=0):
		q=r1/r2
		rs,us,vs=r1,u1,v1
		r1,u1,v1=r2,u2,v2
		r2,u2,v2=rs-q*r2,us-q*u2,vs-q*v2
	return [r1,u1,v1]
