#! /usr/bin/env python
# -*-coding:utf-8 -*
import math
execfile('premiers.py')

	
def primalite(liste):
	reponse=[]
	racine=int(math.sqrt(max(liste)))+2
	l=premiers(racine)
	for nombre in liste:
		for p in l:
			if p != nombre:
				if nombre % p ==0 :
					reponse.append(False)
					break
		else:
			reponse.append(True)
	return reponse
