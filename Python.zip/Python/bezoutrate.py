#! /usr/bin/env python
# -*-coding:utf-8 -*
import math
execfile('premiers.py')

# Fonction donnant la décomposition en facteur premier
def factor(n,listep):
	l=[]
	for i in listep:
		count=0
		while n%i==0:
			n=n/i
			count=count+1
		if count!=0:
			l.append([i,count])
	if n!=1:
		l.append([n,1])
	return l
	
# Fonction de calcul du PGCD à partir des décompositions en facteurs premiers des deux nombres
def pgcd(a,b):
	racine=int(math.sqrt(max(a,b)))
	lp=premiers(racine)
	decompa=factor(a,lp)
	decompb=factor(b,lp)
	decompgcd=[]
	for fa in decompa:
		for fb in decompb:
			if fa[0]==fb[0]:
				decompgcd.append([fa[0],min(fa[1],fb[1])])
	n=1
	for f in decompgcd:
		n=n*math.pow(f[0],f[1])
	return n
