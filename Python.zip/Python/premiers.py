#! /usr/bin/env python
# -*-coding:utf-8 -*

def premiers(n):
	liste  = range(2,n)                           
	nombre = 2
	while nombre*nombre <= n:                       
		for i in liste[liste.index(nombre) + 1:]:  
			if i % nombre == 0:
				liste.remove(i)
		nombre = liste[liste.index(nombre)+1]
	return liste
